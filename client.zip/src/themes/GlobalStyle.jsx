import { createGlobalStyle } from "styled-components";
import SFProDisplayBlack from "../assets/fonts/SFProDisplay-Black.ttf"
import SFProDisplayBold from "../assets/fonts/SFProDisplay-Bold.ttf"
import SFProDisplayHeavy from "../assets/fonts/SFProDisplay-Heavy.ttf"
import SFProDisplayLight from "../assets/fonts/SFProDisplay-Light.ttf"
import SFProDisplayMedium from "../assets/fonts/SFProDisplay-Medium.ttf"
import SFProDisplayRegular from "../assets/fonts/SFProDisplay-Regular.ttf"
import SFProDisplaySemibold from "../assets/fonts/SFProDisplay-Semibold.ttf"
import SFProDisplayThin from "../assets/fonts/SFProDisplay-Thin.ttf"

export const GlobalStyle = createGlobalStyle`
    @font-face {
      font-family: "SF Pro Display";
      src: url(${SFProDisplayBlack}) format('truetype');
      font-weight: 900;
      font-style: normal;
    }
    @font-face {
      font-family: "SF Pro Display";
      src: url(${SFProDisplayBold}) format('truetype');
      font-weight: 700;
      font-style: normal;
    }
    @font-face {
      font-family: "SF Pro Display";
      src: url(${SFProDisplayHeavy}) format('truetype');
      font-weight: 200;
      font-style: normal;
    }
    @font-face {
      font-family: "SF Pro Display";
      src: url(${SFProDisplayLight}) format('truetype');
      font-weight: 300;
      font-style: normal;
    }
    @font-face {
      font-family: "SF Pro Display";
      src: url(${SFProDisplayMedium}) format('truetype');
      font-weight: 500;
      font-style: normal;
    }
    @font-face {
      font-family: "SF Pro Display";
      src: url(${SFProDisplayRegular}) format('truetype');
      font-weight: 400;
      font-style: normal;
    }
    @font-face {
      font-family: "SF Pro Display";
      src: url(${SFProDisplaySemibold}) format('truetype');
      font-weight: 600;
      font-style: normal;
    }
    @font-face {
      font-family: "SF Pro Display";
      src: url(${SFProDisplayThin}) format('truetype');
      font-weight: 100;
      font-style: normal;
    }

  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
  html {
    scroll-behavior: smooth;
  }
  body {
    font-family: 'SF Pro Display', sans-serif;
    font-size: 16px;
    line-height: 20px;
    color: #4B565F;
    background-color: #fff;

    ::-webkit-scrollbar {
      
    width: 8px;

    }

    /* Track */
    ::-webkit-scrollbar-track {
      background: #f1f1f1; 
    }
 
    /* Handle */
    ::-webkit-scrollbar-thumb {
      border-radius: 8px;
      background:#1B90D2
    }

    /* Handle on hover */
    ::-webkit-scrollbar-thumb:hover {
      background: #1198e5; 
    }
    
    
  }
  ul li {
    margin: 0;
    padding: 0;
    list-style-type: none;
  }
  a {
    text-decoration: none;
  }

`;